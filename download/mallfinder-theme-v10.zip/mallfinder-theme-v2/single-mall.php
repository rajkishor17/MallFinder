<?php
/**
 * Single Mall Template
 *
 * @package MallFinder
 */

get_header();

while (have_posts()) : the_post();
    $mall_id = get_the_ID();
    $image = get_the_post_thumbnail_url($mall_id, 'full');
    $category = get_post_meta($mall_id, '_mall_category', true);
    $is_upcoming = ($category === 'upcoming');
    $address = mallfinder_format_address($mall_id);
    $opening_hours = get_post_meta($mall_id, '_mall_opening_hours', true);
    $phone = get_post_meta($mall_id, '_mall_phone', true);
    $stores_count = mallfinder_get_mall_stores_count($mall_id);
    $lat = get_post_meta($mall_id, '_mall_latitude', true);
    $lng = get_post_meta($mall_id, '_mall_longitude', true);
    
    // Get stores for this mall
    $stores = get_posts(array(
        'post_type'      => 'store',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_key'       => '_store_mall_id',
        'meta_value'     => $mall_id,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ));
?>

<!-- Hero Section -->
<div class="mall-hero">
    <?php if ($image) : ?>
        <div class="mall-hero-image">
            <img src="<?php echo esc_url($image); ?>" alt="<?php the_title_attribute(); ?>">
        </div>
    <?php else : ?>
        <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 96px; height: 96px; color: rgba(255,255,255,0.2);">
                <path d="M3 21h18"></path>
                <path d="M5 21V7l8-4v18"></path>
                <path d="M19 21V11l-6-4"></path>
            </svg>
        </div>
    <?php endif; ?>
    
    <div class="mall-hero-content">
        <div class="container">
            <span class="badge <?php echo $is_upcoming ? 'badge-upcoming' : 'badge-existing'; ?>" style="margin-bottom: 0.75rem;">
                <?php if ($is_upcoming) : ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px;"><path d="M12 3l1.912 5.813L20 10l-6.088 1.187L12 17l-1.912-5.813L4 10l6.088-1.187L12 3z"></path></svg>
                    <?php _e('Upcoming Mall', 'mallfinder'); ?>
                <?php else : ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px;"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                    <?php _e('Existing Mall', 'mallfinder'); ?>
                <?php endif; ?>
            </span>
            <h1><?php the_title(); ?></h1>
            <div class="mall-hero-meta">
                <div class="mall-hero-meta-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                    <span><?php echo esc_html($address); ?></span>
                </div>
                <?php if ($opening_hours) : ?>
                    <div class="mall-hero-meta-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                        <span><?php echo esc_html($opening_hours); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="container" style="padding-top: 2rem; padding-bottom: 2rem;">
    
    <!-- Mall Search Box -->
    <div class="search-box">
        <form class="search-form" method="GET" action="<?php echo esc_url(home_url('/')); ?>">
            <div class="search-main-row">
                <div class="search-input-wrapper" style="position: relative;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" name="s" id="mall-search-input-single" class="search-input" placeholder="<?php esc_attr_e('Search malls by name, state, city, area, or address...', 'mallfinder'); ?>" autocomplete="off">
                    <div id="search-suggestions-single" class="search-suggestions"></div>
                </div>
                <select name="category" id="category-filter-single" class="form-select search-select">
                    <option value="all"><?php _e('All Categories', 'mallfinder'); ?></option>
                    <option value="existing"><?php _e('Existing', 'mallfinder'); ?></option>
                    <option value="upcoming"><?php _e('Upcoming', 'mallfinder'); ?></option>
                </select>
                <input type="hidden" name="post_type" value="mall">
                <button type="submit" class="btn btn-primary" id="search-btn-single">
                    <?php _e('Search', 'mallfinder'); ?>
                </button>
            </div>
        </form>
    </div>

    <!-- Mall Details & Map -->
    <div class="mall-content-grid">
        <!-- About Card -->
        <div class="info-card">
            <h3><?php _e('About', 'mallfinder'); ?></h3>
            <?php if (get_the_content()) : ?>
                <div class="mall-description" style="color: var(--slate-600); margin-bottom: 1rem; line-height: 1.7;">
                    <?php the_content(); ?>
                </div>
            <?php elseif (has_excerpt()) : ?>
                <p style="color: var(--slate-600); margin-bottom: 1rem;"><?php echo wp_trim_words(get_the_excerpt(), 50); ?></p>
            <?php else : ?>
                <p style="color: var(--slate-500); font-style: italic; margin-bottom: 1rem;"><?php _e('No description available for this mall.', 'mallfinder'); ?></p>
            <?php endif; ?>
            
            <div class="info-item">
                <div class="info-item-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                </div>
                <div class="info-item-content">
                    <div class="info-item-label"><?php _e('Address', 'mallfinder'); ?></div>
                    <div class="info-item-value"><?php echo esc_html($address); ?></div>
                </div>
            </div>
            
            <?php if ($opening_hours) : ?>
                <div class="info-item">
                    <div class="info-item-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                    </div>
                    <div class="info-item-content">
                        <div class="info-item-label"><?php _e('Opening Hours', 'mallfinder'); ?></div>
                        <div class="info-item-value"><?php echo esc_html($opening_hours); ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($phone) : ?>
                <div class="info-item">
                    <div class="info-item-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                    </div>
                    <div class="info-item-content">
                        <div class="info-item-label"><?php _e('Phone', 'mallfinder'); ?></div>
                        <div class="info-item-value"><?php echo esc_html($phone); ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="info-item">
                <div class="info-item-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                </div>
                <div class="info-item-content">
                    <div class="info-item-label"><?php _e('Total Stores', 'mallfinder'); ?></div>
                    <div class="info-item-value"><?php echo esc_html($stores_count); ?> <?php _e('stores', 'mallfinder'); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Map Card -->
        <div class="info-card">
            <h3><?php _e('Location', 'mallfinder'); ?></h3>
            <div class="map-container" style="height: 300px;">
                <div id="mall-single-map" style="width: 100%; height: 100%;"></div>
            </div>
            <?php if (!$lat || !$lng) : ?>
                <p style="color: var(--slate-500); font-size: 0.875rem; margin-top: 0.75rem; text-align: center;">
                    <?php _e('Location coordinates not available for this mall.', 'mallfinder'); ?>
                </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stores Section -->
    <?php if (!empty($stores)) : ?>
        <section class="section">
            <div class="section-header">
                <div>
                    <h2 class="section-title"><?php _e('Stores', 'mallfinder'); ?></h2>
                    <p class="section-subtitle">
                        <?php printf(_n('%s store', '%s stores', count($stores), 'mallfinder'), number_format_i18n(count($stores))); ?>
                    </p>
                </div>
            </div>

            <div class="store-list">
                <?php foreach ($stores as $store) : ?>
                    <?php
                    $store_id = $store->ID;
                    $store_image = mallfinder_get_store_image($store_id);
                    $store_category = get_post_meta($store_id, '_store_category', true);
                    $store_floor = get_post_meta($store_id, '_store_floor', true);
                    $store_unit = get_post_meta($store_id, '_store_unit', true);
                    $store_status = get_post_meta($store_id, '_store_status', true);
                    
                    $status_class = '';
                    $status_label = '';
                    switch ($store_status) {
                        case 'OPEN':
                            $status_class = 'badge-open';
                            $status_label = __('Open', 'mallfinder');
                            break;
                        case 'COMING_SOON':
                            $status_class = 'badge-coming-soon';
                            $status_label = __('Coming Soon', 'mallfinder');
                            break;
                        case 'CLOSED':
                            $status_class = 'badge-closed';
                            $status_label = __('Closed', 'mallfinder');
                            break;
                        default:
                            $status_class = 'badge-open';
                            $status_label = __('Open', 'mallfinder');
                    }
                    ?>
                    <article class="store-card <?php echo $store_status === 'CLOSED' ? 'closed' : ''; ?>">
                        <div class="store-card-image">
                            <img src="<?php echo esc_url($store_image); ?>" alt="<?php echo esc_attr($store->post_title); ?>">
                        </div>
                        <div class="store-card-body">
                            <div class="store-card-header">
                                <div>
                                    <h3 class="store-card-title"><?php echo esc_html($store->post_title); ?></h3>
                                    <p class="store-card-category"><?php echo esc_html($store_category); ?></p>
                                </div>
                                <span class="badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_label); ?></span>
                            </div>
                            <?php if ($store_floor || $store_unit) : ?>
                                <div class="store-card-location">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                    <span><?php echo esc_html(trim($store_floor . ' - ' . $store_unit, ' -')); ?></span>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo esc_url(get_permalink($store_id)); ?>" class="btn btn-sm btn-primary" style="width: 100%; margin-top: 0.75rem;">
                                <?php _e('View Details', 'mallfinder'); ?>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php else : ?>
        <section class="section">
            <div class="section-header">
                <div>
                    <h2 class="section-title"><?php _e('Stores', 'mallfinder'); ?></h2>
                    <p class="section-subtitle"><?php _e('No stores listed yet', 'mallfinder'); ?></p>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<!-- Map Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($lat && $lng) : ?>
    var lat = parseFloat('<?php echo esc_js($lat); ?>');
    var lng = parseFloat('<?php echo esc_js($lng); ?>');
    
    // Check if Leaflet is loaded
    if (typeof L !== 'undefined') {
        // Initialize the map
        var mapContainer = document.getElementById('mall-single-map');
        if (mapContainer) {
            var map = L.map('mall-single-map', {
                center: [lat, lng],
                zoom: 15
            });
            
            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 19
            }).addTo(map);
            
            // Create custom marker icon
            var markerColor = '<?php echo $is_upcoming ? '#f59e0b' : '#10b981'; ?>';
            var customIcon = L.divIcon({
                html: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="' + markerColor + '" width="32" height="32"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>',
                className: 'custom-marker-icon',
                iconSize: [32, 32],
                iconAnchor: [16, 32],
                popupAnchor: [0, -32]
            });
            
            // Add marker with popup
            L.marker([lat, lng], { icon: customIcon }).addTo(map)
                .bindPopup('<strong><?php echo esc_js(get_the_title()); ?></strong><br><?php echo esc_js($address); ?>');
            
            // Force map to redraw after a short delay
            setTimeout(function() {
                map.invalidateSize();
            }, 100);
        }
    } else {
        console.log('Leaflet library not loaded');
    }
    <?php endif; ?>
});
</script>

<?php
// Get other malls for "Explore Other Malls" section
$other_malls = get_posts(array(
    'post_type'      => 'mall',
    'posts_per_page' => 10,
    'post_status'    => 'publish',
    'post__not_in'   => array($mall_id),
    'orderby'        => 'date',
    'order'          => 'DESC',
));
?>

<!-- Explore Other Malls Section -->
<?php if (!empty($other_malls)) : ?>
<section class="explore-malls-section">
    <div class="container">
        <div class="explore-section-header">
            <h2 class="explore-section-title"><?php _e('Explore Other Malls', 'mallfinder'); ?></h2>
            <p class="explore-section-subtitle"><?php _e('Discover more shopping destinations near you', 'mallfinder'); ?></p>
        </div>
        
        <div class="explore-malls-carousel-wrapper">
            <button class="carousel-btn carousel-btn-prev" id="single-carousel-prev" aria-label="Previous">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
            
            <div class="explore-malls-carousel" id="explore-malls-carousel">
                <?php foreach ($other_malls as $other_mall) : ?>
                    <?php
                    $other_image = mallfinder_get_mall_image($other_mall->ID);
                    $other_category = get_post_meta($other_mall->ID, '_mall_category', true);
                    $other_is_upcoming = ($other_category === 'upcoming');
                    $other_address = mallfinder_format_address($other_mall->ID);
                    ?>
                    <a href="<?php echo esc_url(get_permalink($other_mall->ID)); ?>" class="explore-mall-card <?php echo $other_is_upcoming ? 'upcoming' : ''; ?>">
                        <div class="explore-mall-image">
                            <?php if ($other_image) : ?>
                                <img src="<?php echo esc_url($other_image); ?>" alt="<?php echo esc_attr($other_mall->post_title); ?>">
                            <?php else : ?>
                                <div class="explore-mall-placeholder">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M3 21h18"></path>
                                        <path d="M5 21V7l8-4v18"></path>
                                        <path d="M19 21V11l-6-4"></path>
                                    </svg>
                                </div>
                            <?php endif; ?>
                            <span class="explore-mall-badge <?php echo $other_is_upcoming ? 'badge-upcoming' : 'badge-existing'; ?>">
                                <?php echo $other_is_upcoming ? __('Upcoming', 'mallfinder') : __('Existing', 'mallfinder'); ?>
                            </span>
                        </div>
                        <div class="explore-mall-content">
                            <h3><?php echo esc_html($other_mall->post_title); ?></h3>
                            <p><?php echo esc_html(wp_trim_words($other_address, 8)); ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
            
            <button class="carousel-btn carousel-btn-next" id="single-carousel-next" aria-label="Next">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>
        </div>
        
        <div class="explore-section-footer">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary"><?php _e('View All Malls', 'mallfinder'); ?></a>
        </div>
    </div>
</section>

<script>
(function() {
    var carousel = document.getElementById('explore-malls-carousel');
    var prevBtn = document.getElementById('single-carousel-prev');
    var nextBtn = document.getElementById('single-carousel-next');
    
    if (carousel && prevBtn && nextBtn) {
        var scrollAmount = 300;
        
        prevBtn.addEventListener('click', function(e) {
            e.preventDefault();
            carousel.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });
        
        nextBtn.addEventListener('click', function(e) {
            e.preventDefault();
            carousel.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });
    }
})();
</script>
<?php endif; ?>

<!-- Search Autocomplete Script for Single Mall Page -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('mall-search-input-single');
    var suggestionsBox = document.getElementById('search-suggestions-single');
    var searchTimeout = null;
    
    if (searchInput && suggestionsBox) {
        searchInput.addEventListener('input', function() {
            var searchTerm = this.value.trim();
            
            clearTimeout(searchTimeout);
            
            if (searchTerm.length < 2) {
                suggestionsBox.innerHTML = '';
                suggestionsBox.style.display = 'none';
                return;
            }
            
            searchTimeout = setTimeout(function() {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', '<?php echo admin_url('admin-ajax.php'); ?>?action=mallfinder_search&term=' + encodeURIComponent(searchTerm) + '&category=all&nonce=<?php echo wp_create_nonce('mallfinder_nonce'); ?>', true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        try {
                            var results = JSON.parse(xhr.responseText);
                            if (results.length > 0) {
                                var html = '';
                                results.forEach(function(mall) {
                                    var badgeClass = mall.category === 'upcoming' ? 'badge-upcoming' : 'badge-existing';
                                    var badgeText = mall.category === 'upcoming' ? 'Upcoming' : 'Existing';
                                    html += '<a href="' + mall.url + '" class="suggestion-item">';
                                    html += '<img src="' + mall.image + '" alt="' + mall.title + '" class="suggestion-image">';
                                    html += '<div class="suggestion-content">';
                                    html += '<div class="suggestion-title">' + mall.title + '</div>';
                                    html += '<div class="suggestion-address">' + mall.address + '</div>';
                                    html += '</div>';
                                    html += '<span class="suggestion-badge ' + badgeClass + '">' + badgeText + '</span>';
                                    html += '</a>';
                                });
                                suggestionsBox.innerHTML = html;
                                suggestionsBox.style.display = 'block';
                            } else {
                                suggestionsBox.innerHTML = '<div class="suggestion-empty">No malls found</div>';
                                suggestionsBox.style.display = 'block';
                            }
                        } catch (e) {
                            console.error('Parse error:', e);
                        }
                    }
                };
                xhr.send();
            }, 300);
        });
        
        // Hide suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
                suggestionsBox.style.display = 'none';
            }
        });
        
        // Show suggestions on focus if there's content
        searchInput.addEventListener('focus', function() {
            if (this.value.length >= 2) {
                this.dispatchEvent(new Event('input'));
            }
        });
    }
});
</script>

<?php
endwhile;
get_footer();
