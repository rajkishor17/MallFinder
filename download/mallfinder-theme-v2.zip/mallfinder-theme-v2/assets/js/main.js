/**
 * MallFinder Theme JavaScript
 *
 * @package MallFinder
 */

(function($) {
    'use strict';

    // Mobile Menu Toggle
    $(document).ready(function() {
        $('.menu-toggle').on('click', function() {
            $('.main-nav').toggleClass('active');
            
            // Toggle icon
            var $icon = $(this).find('svg');
            if ($icon.length) {
                if ($('.main-nav').hasClass('active')) {
                    $icon.html('<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>');
                } else {
                    $icon.html('<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>');
                }
            }
        });

        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.site-header').length) {
                $('.main-nav').removeClass('active');
            }
        });

        // Smooth scroll for anchor links
        $('a[href*="#"]:not([href="#"])').on('click', function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 80
                    }, 500);
                    return false;
                }
            }
        });

        // Add animation to cards on scroll
        var observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('slide-up');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        document.querySelectorAll('.mall-card, .store-card').forEach(function(card) {
            observer.observe(card);
        });

        // Initialize map if container exists and Leaflet is loaded
        if (typeof L !== 'undefined') {
            initializeMaps();
        }
    });

    /**
     * Initialize Maps
     */
    function initializeMaps() {
        // Home page map
        var $homeMap = $('#home-map');
        if ($homeMap.length && typeof mallfinderData !== 'undefined') {
            // Map is initialized in index.php with inline script
        }

        // Single mall map
        var $mallMap = $('#mall-single-map');
        if ($mallMap.length && typeof mallfinderData !== 'undefined') {
            // Map is initialized in single-mall.php with inline script
        }
    }

    /**
     * Search functionality
     */
    $(document).ready(function() {
        var $searchInput = $('.search-input');
        var searchTimeout;

        $searchInput.on('input', function() {
            clearTimeout(searchTimeout);
            var query = $(this).val();
            
            if (query.length >= 2) {
                // Could add live search suggestions here
            }
        });

        // Handle form submission
        $('.search-box form').on('submit', function(e) {
            // Allow normal form submission
        });
    });

    /**
     * Filter functionality
     */
    $(document).ready(function() {
        $('select[name="category"]').on('change', function() {
            $(this).closest('form').submit();
        });
    });

    /**
     * Back to top button
     */
    $(document).ready(function() {
        // Create back to top button
        var $backToTop = $('<button class="back-to-top" aria-label="Back to top" style="display: none; position: fixed; bottom: 20px; right: 20px; width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(to right, #10b981, #14b8a6); color: white; border: none; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 999;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 24px; height: 24px;"><polyline points="18 15 12 9 6 15"></polyline></svg></button>');
        
        $('body').append($backToTop);

        // Show/hide button based on scroll position
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > 300) {
                $backToTop.fadeIn();
            } else {
                $backToTop.fadeOut();
            }
        });

        // Scroll to top on click
        $backToTop.on('click', function() {
            $('html, body').animate({ scrollTop: 0 }, 500);
        });
    });

})(jQuery);
