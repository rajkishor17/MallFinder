<?php
/**
 * MallFinder Theme Functions
 *
 * @package MallFinder
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Theme version
define('MALLFINDER_VERSION', '1.0.0');

/**
 * Theme Setup
 */
function mallfinder_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Image sizes
    add_image_size('mall-thumbnail', 400, 300, true);
    add_image_size('mall-hero', 1920, 600, true);
    add_image_size('store-logo', 200, 200, true);

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'mallfinder'),
        'footer'  => __('Footer Menu', 'mallfinder'),
    ));
}
add_action('after_setup_theme', 'mallfinder_setup');

/**
 * Enqueue Scripts and Styles
 */
function mallfinder_scripts() {
    // Styles
    wp_enqueue_style('mallfinder-style', get_stylesheet_uri(), array(), MALLFINDER_VERSION);
    wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4');

    // Scripts
    wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
    wp_enqueue_script('mallfinder-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery', 'leaflet-js'), MALLFINDER_VERSION, true);

    // Localize script
    wp_localize_script('mallfinder-main', 'mallfinderData', array(
        'ajaxUrl'     => admin_url('admin-ajax.php'),
        'nonce'       => wp_create_nonce('mallfinder_nonce'),
        'defaultLat'  => get_option('mallfinder_default_lat', '40.7128'),
        'defaultLng'  => get_option('mallfinder_default_lng', '-74.0060'),
        'defaultZoom' => get_option('mallfinder_default_zoom', '12'),
    ));
}
add_action('wp_enqueue_scripts', 'mallfinder_scripts');

/**
 * Register Mall Post Type
 */
function mallfinder_register_mall_post_type() {
    $labels = array(
        'name'               => __('Malls', 'mallfinder'),
        'singular_name'      => __('Mall', 'mallfinder'),
        'menu_name'          => __('Malls', 'mallfinder'),
        'all_items'          => __('All Malls', 'mallfinder'),
        'add_new_item'       => __('Add New Mall', 'mallfinder'),
        'edit_item'          => __('Edit Mall', 'mallfinder'),
        'featured_image'     => __('Mall Image', 'mallfinder'),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => true,
        'menu_icon'           => 'dashicons-store',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite'             => array('slug' => 'malls'),
        'show_in_rest'        => true,
    );

    register_post_type('mall', $args);
}
add_action('init', 'mallfinder_register_mall_post_type');

/**
 * Register Store Post Type
 */
function mallfinder_register_store_post_type() {
    $labels = array(
        'name'               => __('Stores', 'mallfinder'),
        'singular_name'      => __('Store', 'mallfinder'),
        'menu_name'          => __('Stores', 'mallfinder'),
        'all_items'          => __('All Stores', 'mallfinder'),
        'add_new_item'       => __('Add New Store', 'mallfinder'),
        'edit_item'          => __('Edit Store', 'mallfinder'),
        'featured_image'     => __('Store Logo', 'mallfinder'),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => true,
        'menu_icon'           => 'dashicons-cart',
        'supports'            => array('title', 'editor', 'thumbnail'),
        'rewrite'             => array('slug' => 'stores'),
        'show_in_rest'        => true,
    );

    register_post_type('store', $args);
}
add_action('init', 'mallfinder_register_store_post_type');

/**
 * Add Meta Box for Mall Details
 */
function mallfinder_add_mall_meta_box() {
    add_meta_box(
        'mall_details',
        __('Mall Details', 'mallfinder'),
        'mallfinder_mall_meta_box_callback',
        'mall',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'mallfinder_add_mall_meta_box');

function mallfinder_mall_meta_box_callback($post) {
    wp_nonce_field('mallfinder_mall_meta', 'mallfinder_mall_meta_nonce');
    
    $fields = array(
        'address' => __('Address', 'mallfinder'),
        'area' => __('Area', 'mallfinder'),
        'city' => __('City', 'mallfinder'),
        'state' => __('State', 'mallfinder'),
        'pincode' => __('PIN Code', 'mallfinder'),
        'latitude' => __('Latitude', 'mallfinder'),
        'longitude' => __('Longitude', 'mallfinder'),
        'phone' => __('Phone', 'mallfinder'),
        'opening_hours' => __('Opening Hours', 'mallfinder'),
        'total_stores' => __('Total Stores', 'mallfinder'),
        'category' => __('Category', 'mallfinder'),
    );
    
    echo '<table class="form-table">';
    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, '_mall_' . $key, true);
        echo '<tr>';
        echo '<th><label for="mall_' . esc_attr($key) . '">' . esc_html($label) . '</label></th>';
        echo '<td>';
        if ($key === 'category') {
            echo '<select name="mall_' . esc_attr($key) . '" id="mall_' . esc_attr($key) . '">';
            echo '<option value="existing"' . selected($value, 'existing', false) . '>' . __('Existing', 'mallfinder') . '</option>';
            echo '<option value="upcoming"' . selected($value, 'upcoming', false) . '>' . __('Upcoming', 'mallfinder') . '</option>';
            echo '</select>';
        } else {
            echo '<input type="text" name="mall_' . esc_attr($key) . '" id="mall_' . esc_attr($key) . '" value="' . esc_attr($value) . '" class="regular-text">';
        }
        echo '</td>';
        echo '</tr>';
    }
    echo '</table>';
}

function mallfinder_save_mall_meta($post_id) {
    if (!isset($_POST['mallfinder_mall_meta_nonce']) || !wp_verify_nonce($_POST['mallfinder_mall_meta_nonce'], 'mallfinder_mall_meta')) {
        return;
    }
    
    $fields = array('address', 'area', 'city', 'state', 'pincode', 'latitude', 'longitude', 'phone', 'opening_hours', 'total_stores', 'category');
    
    foreach ($fields as $field) {
        if (isset($_POST['mall_' . $field])) {
            update_post_meta($post_id, '_mall_' . $field, sanitize_text_field($_POST['mall_' . $field]));
        }
    }
}
add_action('save_post_mall', 'mallfinder_save_mall_meta');

/**
 * Add Meta Box for Store Details
 */
function mallfinder_add_store_meta_box() {
    add_meta_box(
        'store_details',
        __('Store Details', 'mallfinder'),
        'mallfinder_store_meta_box_callback',
        'store',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'mallfinder_add_store_meta_box');

function mallfinder_store_meta_box_callback($post) {
    wp_nonce_field('mallfinder_store_meta', 'mallfinder_store_meta_nonce');
    
    $fields = array(
        'mall_id' => __('Mall', 'mallfinder'),
        'floor' => __('Floor', 'mallfinder'),
        'unit' => __('Unit Number', 'mallfinder'),
        'phone' => __('Phone', 'mallfinder'),
        'website' => __('Website', 'mallfinder'),
        'opening_hours' => __('Opening Hours', 'mallfinder'),
        'category' => __('Category', 'mallfinder'),
        'status' => __('Status', 'mallfinder'),
    );
    
    // Get malls for dropdown
    $malls = get_posts(array('post_type' => 'mall', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    
    echo '<table class="form-table">';
    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, '_store_' . $key, true);
        echo '<tr>';
        echo '<th><label for="store_' . esc_attr($key) . '">' . esc_html($label) . '</label></th>';
        echo '<td>';
        
        if ($key === 'mall_id') {
            echo '<select name="store_' . esc_attr($key) . '" id="store_' . esc_attr($key) . '">';
            echo '<option value="">' . __('Select Mall', 'mallfinder') . '</option>';
            foreach ($malls as $mall) {
                echo '<option value="' . $mall->ID . '"' . selected($value, $mall->ID, false) . '>' . esc_html($mall->post_title) . '</option>';
            }
            echo '</select>';
        } elseif ($key === 'status') {
            echo '<select name="store_' . esc_attr($key) . '" id="store_' . esc_attr($key) . '">';
            echo '<option value="OPEN"' . selected($value, 'OPEN', false) . '>' . __('Open', 'mallfinder') . '</option>';
            echo '<option value="COMING_SOON"' . selected($value, 'COMING_SOON', false) . '>' . __('Coming Soon', 'mallfinder') . '</option>';
            echo '<option value="CLOSED"' . selected($value, 'CLOSED', false) . '>' . __('Closed', 'mallfinder') . '</option>';
            echo '</select>';
        } else {
            echo '<input type="text" name="store_' . esc_attr($key) . '" id="store_' . esc_attr($key) . '" value="' . esc_attr($value) . '" class="regular-text">';
        }
        echo '</td>';
        echo '</tr>';
    }
    echo '</table>';
}

function mallfinder_save_store_meta($post_id) {
    if (!isset($_POST['mallfinder_store_meta_nonce']) || !wp_verify_nonce($_POST['mallfinder_store_meta_nonce'], 'mallfinder_store_meta')) {
        return;
    }
    
    $fields = array('mall_id', 'floor', 'unit', 'phone', 'website', 'opening_hours', 'category', 'status');
    
    foreach ($fields as $field) {
        if (isset($_POST['store_' . $field])) {
            update_post_meta($post_id, '_store_' . $field, sanitize_text_field($_POST['store_' . $field]));
        }
    }
}
add_action('save_post_store', 'mallfinder_save_store_meta');

/**
 * Helper Functions
 */
function mallfinder_get_mall_image($post_id) {
    if (has_post_thumbnail($post_id)) {
        return get_the_post_thumbnail_url($post_id, 'mall-thumbnail');
    }
    return get_template_directory_uri() . '/assets/images/default-mall.jpg';
}

function mallfinder_get_store_image($post_id) {
    if (has_post_thumbnail($post_id)) {
        return get_the_post_thumbnail_url($post_id, 'store-logo');
    }
    return get_template_directory_uri() . '/assets/images/default-store.png';
}

function mallfinder_get_mall_stores_count($mall_id) {
    $stores = get_posts(array(
        'post_type' => 'store',
        'posts_per_page' => -1,
        'meta_key' => '_store_mall_id',
        'meta_value' => $mall_id,
        'fields' => 'ids',
        'post_status' => 'publish',
    ));
    return count($stores);
}

function mallfinder_format_address($mall_id) {
    $address = get_post_meta($mall_id, '_mall_address', true);
    $area = get_post_meta($mall_id, '_mall_area', true);
    $city = get_post_meta($mall_id, '_mall_city', true);
    $state = get_post_meta($mall_id, '_mall_state', true);
    $pincode = get_post_meta($mall_id, '_mall_pincode', true);
    
    $parts = array_filter(array($address, $area, $city, $state, $pincode));
    return implode(', ', $parts);
}

function mallfinder_get_setting($key, $default = '') {
    return get_option('mallfinder_' . $key, $default);
}

/**
 * Theme Settings Page
 */
function mallfinder_add_settings_page() {
    add_menu_page(
        __('MallFinder Settings', 'mallfinder'),
        __('MallFinder Settings', 'mallfinder'),
        'manage_options',
        'mallfinder-settings',
        'mallfinder_settings_page_html',
        'dashicons-admin-settings',
        60
    );
}
add_action('admin_menu', 'mallfinder_add_settings_page');

function mallfinder_register_settings() {
    register_setting('mallfinder_settings', 'mallfinder_site_name');
    register_setting('mallfinder_settings', 'mallfinder_site_tagline');
    register_setting('mallfinder_settings', 'mallfinder_facebook');
    register_setting('mallfinder_settings', 'mallfinder_twitter');
    register_setting('mallfinder_settings', 'mallfinder_instagram');
    register_setting('mallfinder_settings', 'mallfinder_linkedin');
    register_setting('mallfinder_settings', 'mallfinder_youtube');
    register_setting('mallfinder_settings', 'mallfinder_whatsapp');
    register_setting('mallfinder_settings', 'mallfinder_default_lat');
    register_setting('mallfinder_settings', 'mallfinder_default_lng');
    register_setting('mallfinder_settings', 'mallfinder_default_zoom');
}
add_action('admin_init', 'mallfinder_register_settings');

function mallfinder_settings_page_html() {
    ?>
    <div class="wrap">
        <h1><?php _e('MallFinder Theme Settings', 'mallfinder'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mallfinder_settings');
            ?>
            <table class="form-table">
                <tr>
                    <th><?php _e('Site Name', 'mallfinder'); ?></th>
                    <td><input type="text" name="mallfinder_site_name" value="<?php echo esc_attr(get_option('mallfinder_site_name', 'MallFinder')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Site Tagline', 'mallfinder'); ?></th>
                    <td><input type="text" name="mallfinder_site_tagline" value="<?php echo esc_attr(get_option('mallfinder_site_tagline', 'Discover Shopping Destinations')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Facebook URL', 'mallfinder'); ?></th>
                    <td><input type="url" name="mallfinder_facebook" value="<?php echo esc_attr(get_option('mallfinder_facebook')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Twitter URL', 'mallfinder'); ?></th>
                    <td><input type="url" name="mallfinder_twitter" value="<?php echo esc_attr(get_option('mallfinder_twitter')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Instagram URL', 'mallfinder'); ?></th>
                    <td><input type="url" name="mallfinder_instagram" value="<?php echo esc_attr(get_option('mallfinder_instagram')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('LinkedIn URL', 'mallfinder'); ?></th>
                    <td><input type="url" name="mallfinder_linkedin" value="<?php echo esc_attr(get_option('mallfinder_linkedin')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('YouTube URL', 'mallfinder'); ?></th>
                    <td><input type="url" name="mallfinder_youtube" value="<?php echo esc_attr(get_option('mallfinder_youtube')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('WhatsApp Number', 'mallfinder'); ?></th>
                    <td><input type="text" name="mallfinder_whatsapp" value="<?php echo esc_attr(get_option('mallfinder_whatsapp')); ?>" class="regular-text" placeholder="e.g., 919876543210"></td>
                </tr>
                <tr>
                    <th><?php _e('Default Map Latitude', 'mallfinder'); ?></th>
                    <td><input type="text" name="mallfinder_default_lat" value="<?php echo esc_attr(get_option('mallfinder_default_lat', '40.7128')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Default Map Longitude', 'mallfinder'); ?></th>
                    <td><input type="text" name="mallfinder_default_lng" value="<?php echo esc_attr(get_option('mallfinder_default_lng', '-74.0060')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php _e('Default Map Zoom', 'mallfinder'); ?></th>
                    <td><input type="number" name="mallfinder_default_zoom" value="<?php echo esc_attr(get_option('mallfinder_default_zoom', '12')); ?>" class="small-text"></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * AJAX Search Suggestions
 */
function mallfinder_search_suggestions() {
    check_ajax_referer('mallfinder_nonce', 'nonce');
    
    $search = isset($_GET['term']) ? sanitize_text_field($_GET['term']) : '';
    $category = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : 'all';
    
    if (strlen($search) < 2) {
        wp_send_json(array());
    }
    
    $args = array(
        'post_type'      => 'mall',
        'posts_per_page' => 10,
        'post_status'    => 'publish',
        's'              => $search,
    );
    
    // Add category filter
    if ($category !== 'all') {
        $args['meta_query'] = array(
            array(
                'key'     => '_mall_category',
                'value'   => $category,
                'compare' => '=',
            ),
        );
    }
    
    // Also search in meta fields
    $args['meta_query'] = isset($args['meta_query']) ? $args['meta_query'] : array();
    $args['meta_query']['relation'] = 'OR';
    $args['meta_query'][] = array(
        'key'     => '_mall_address',
        'value'   => $search,
        'compare' => 'LIKE',
    );
    $args['meta_query'][] = array(
        'key'     => '_mall_area',
        'value'   => $search,
        'compare' => 'LIKE',
    );
    $args['meta_query'][] = array(
        'key'     => '_mall_city',
        'value'   => $search,
        'compare' => 'LIKE',
    );
    $args['meta_query'][] = array(
        'key'     => '_mall_state',
        'value'   => $search,
        'compare' => 'LIKE',
    );
    
    $malls = get_posts($args);
    $results = array();
    
    foreach ($malls as $mall) {
        $mall_category = get_post_meta($mall->ID, '_mall_category', true);
        $address = mallfinder_format_address($mall->ID);
        $image = get_the_post_thumbnail_url($mall->ID, 'mall-thumbnail');
        
        $results[] = array(
            'id'        => $mall->ID,
            'title'     => $mall->post_title,
            'url'       => get_permalink($mall->ID),
            'address'   => $address,
            'category'  => $mall_category ?: 'existing',
            'image'     => $image ?: get_template_directory_uri() . '/assets/images/default-mall.jpg',
        );
    }
    
    wp_send_json($results);
}
add_action('wp_ajax_mallfinder_search', 'mallfinder_search_suggestions');
add_action('wp_ajax_nopriv_mallfinder_search', 'mallfinder_search_suggestions');

/**
 * Custom Search Query Filter
 */
function mallfinder_search_filter($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_search()) {
        $query->set('post_type', 'mall');
        
        $search_term = get_search_query();
        $category = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : 'all';
        
        if ($category !== 'all') {
            $meta_query = $query->get('meta_query') ?: array();
            $meta_query[] = array(
                'key'     => '_mall_category',
                'value'   => $category,
                'compare' => '=',
            );
            $query->set('meta_query', $meta_query);
        }
    }
    return $query;
}
add_action('pre_get_posts', 'mallfinder_search_filter');

/**
 * Flush Rewrite Rules on Activation
 */
function mallfinder_activate() {
    mallfinder_register_mall_post_type();
    mallfinder_register_store_post_type();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'mallfinder_activate');
